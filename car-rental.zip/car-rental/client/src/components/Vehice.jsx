import React from 'react'

export default function Vehice() {
  return (
    <div>
        <div className=' vehicle-heading'>
            <h1>Our Vehlicle Fleet</h1>
            <p>We provide our customers with the most incredible driving emotions</p>
            <p>Thats why we have only word-class cars in our fleet</p>
        </div>
        <div className='first-row'>
             <div className="row-1">
                <img src="https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 1" class="card-image"/>
            </div>
            <div className="row-1">
                <img src="https://images.pexels.com/photos/3647693/pexels-photo-3647693.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 2" class="card-image"/>
            </div>
            <div className="row-1">
                <img src="https://images.pexels.com/photos/3972755/pexels-photo-3972755.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 3" class="card-image"/>
            </div>

        </div>
        <div className='second-row'>
            <div className="row-2">
                <img src="https://images.pexels.com/photos/2127733/pexels-photo-2127733.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 1" class="card-image"/>
            </div>
            <div className="row-2">
                <img src="https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 2" class="card-image"/>
            </div>
            <div className="row-2">
                <img src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 1" class="card-image"/>
            </div>
            <div className="row-2">
                <img src="https://images.pexels.com/photos/217326/pexels-photo-217326.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Image 2" class="card-image"/>
            </div>
        </div>
    </div>
  )
}
